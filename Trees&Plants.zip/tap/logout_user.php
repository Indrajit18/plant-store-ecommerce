<?php
session_start();

// Destroy session
if(session_destroy()) {
    // Redirecting to the login page
    header("Location: index.php");
}
?>
