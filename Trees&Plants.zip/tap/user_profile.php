session_start();

if (isset($_SESSION['username'])) {
    echo "Welcome, " . $_SESSION['username'] . "!";
    echo "<a href='edit_profile.php'>Edit Profile</a>";
    echo "<a href='view_orders.php'>View Orders</a>";
} else {
    echo "You are not logged in.";
    echo "<a href='login.php'>Login</a>";
}
