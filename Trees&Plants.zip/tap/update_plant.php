<?php
include "config.php";

$plant_id = $_POST['plant_id'];
$family = $_POST['family'];
$species = $_POST['species'];
$variety = $_POST['variety'];
$quantity = $_POST['quantity'];
$size = $_POST['size'];
$shade = $_POST['shade'];
$dampness = $_POST['dampness'];

$query = "UPDATE plant SET familyID='$family', species='$species', variety='$variety', quantity='$quantity', size='$size', shade='$shade', dampness='$dampness' WHERE pid='$plant_id'";

if ($conn->query($query) === TRUE) {
    header("Location: amend_details.php?success=Plant updated successfully");
} else {
    header("Location: amend_details.php?error=Error updating plant");
}

$conn->close();
?>
