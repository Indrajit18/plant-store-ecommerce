<?php
// Starting session
session_start();

// Check if the user is an admin, if not redirect to login page
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("location: manage_user.php");
    exit;
}

// Establishing a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Getting users from the database
$result = $conn->query("SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Manage Users</title>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd - Manage Users</h1>
    </header>
    <main>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                echo "<td><a href='manage_user.php?id=" . urlencode($row['id']) . "'>Edit</a> | <a href='delete_user.php?id=" . urlencode($row['id']) . "'>Delete</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </main>
</body>
</html>
<?php
$conn->close();
?>
