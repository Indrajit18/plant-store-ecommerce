<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_POST['plant_id'])) {
    $plant_id = $_POST['plant_id'];
    if (isset($_SESSION['cart'][$plant_id])) {
        $_SESSION['cart'][$plant_id]++;
    } else {
        $_SESSION['cart'][$plant_id] = 1;
    }
}

header('Location: search_plant.php');
?>
