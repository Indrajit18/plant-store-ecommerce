<?php
require_once 'config.php';

if (isset($_GET['plant_id'])) {
    $plant_id = $_GET['plant_id'];

    // Preparing a delete statement
    $sql = "DELETE FROM plant WHERE pid = ?";

    if ($stmt = $conn->prepare($sql)) {
        // Binding variables to the prepared statement as parameters
        $stmt->bind_param("i", $param_id);

        // Setting parameters
        $param_id = $plant_id;

        // Attemptting to execute the prepared statement
        if ($stmt->execute()) {
            // Records deleted successfully. Redirect to landing page
            header("location: amend_details.php");
            exit();
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
