<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Enter Address</title>
    <style>
        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
        }

        .input-group input {
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd - Enter Address</h1>
    </header>
    <main>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // TODO: You might want to add validation for the input here and save it in session or database

            // Then redirect to the checkout page
            header("Location: checkout.php");
            exit;
        }
        ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="input-group">
                <label for="street">Street:</label>
                <input type="text" id="street" name="street" required>
            </div>
            <div class="input-group">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" required>
            </div>
            <div class="input-group">
                <label for="state">State:</label>
                <input type="text" id="state" name="state" required>
            </div>
            <div class="input-group">
                <label for="zip">ZIP Code:</label>
                <input type="text" id="zip" name="zip" required>
            </div>
            <input type="submit" value="Proceed to Checkout">
        </form>
    </main>
</body>
</html>
