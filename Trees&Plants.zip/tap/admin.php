<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Admin Dashboard</title>
    <style>
        /* Add custom styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            color: #333;
        }

        header {
            background-color: #4CAF50;
            color: #fff;
            padding: 20px;
        }

        h1 {
            margin: 0;
        }

        main {
            padding: 20px;
            display: flex;
            justify-content: space-between;
        }

        section {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            flex-basis: 48%;
        }

        h2 {
            margin-top: 0;
        }

        .admin-options {
            list-style-type: none;
            padding: 0;
        }

        .admin-options li {
            margin-bottom: 10px;
        }

        .admin-options li a {
            display: block;
            padding: 10px;
            background-color: #fff;
            text-decoration: none;
            color: #4CAF50;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .admin-options li a:hover {
            background-color: #e0e0e0;
        }

        footer {
            background-color: #4CAF50;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        button {
            border: none;
            background-color: transparent;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the Admin Page!</h1>
    </header>
    
    <main>
        <section>
            <h2>Admin Dashboard</h2>
            <ul class="admin-options">
                <li><a href="amend_details.php">Amend Plant Details</a></li>
                <li><a href="data_entry.php">Add New Plant</a></li>
                <li><a href="view_orders.php">View Orders</a></li>
                <li><a href="manage_user.php">Manage Users</a></li>
            </ul>
        </section>
        <section>
            <h2>Site Statistics</h2>
            <p>Registered Users: 100</p>
            <p>Orders Today: 20</p>
            <p>Total Plants: 150</p>
        </section>
    </main>
    <footer>
        <button><a href="logout.php">Logout</a></button>
    </footer>
</body>
</html>
