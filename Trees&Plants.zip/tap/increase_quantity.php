<?php
session_start();

if (isset($_GET['plant_id'])) {
    $plant_id = $_GET['plant_id'];

    if (isset($_SESSION['cart'][$plant_id])) {
        $_SESSION['cart'][$plant_id]++;
    }
}

header('Location: view_cart.php');
