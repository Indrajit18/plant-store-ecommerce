<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trees and Plants Ltd - Amend Details</title>
  <link rel="stylesheet" href="style.css">
  <style>
    /* Add custom styles here */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
      color: #333;
    }

    header {
      background-color: #4CAF50;
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    h1 {
      margin: 0;
    }

    main {
      padding: 20px;
    }

    form {
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
    }

    input[type="text"] {
      padding: 5px;
      width: 200px;
    }

    input[type="submit"] {
      padding: 5px 10px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #4CAF50;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #e0e0e0;
    }

    .no-results {
      margin-top: 10px;
      color: #f44336;
    }
  </style>
</head>
<body>
  <header>
    <h1>Trees and Plants Ltd - Amend Details</h1>
  </header>

  <nav>
    <ul>
      <li class="dropdown">
        <a href="javascript:void(0)" class="dropbtn">More</a>
        <div class="dropdown-content">
          <a href="index.php">Home</a>
          <a href="view_cart.php">Cart</a>
        </div>
      </li>
    </ul>
  </nav>

  <main>
    <form action="amend_details.php" method="post">
      <label for="search">Plant name or ID:</label>
      <input type="text" name="search" id="search" required>
      <input type="submit" value="Search">
    </form>

    <h2>Search Results:</h2>

    <?php
    require_once 'config.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $search = isset($_POST['search']) ? $_POST['search'] : '';
      $plants = search_plants($conn, $search);

      if (count($plants) > 0) {
        echo '<table>';
        echo '<tr><th>Plant ID</th><th>Species</th><th>Family</th><th>Action</th></tr>';
        foreach ($plants as $plant) {
          echo '<tr>';
          echo '<td>' . $plant['pid'] . '</td>';
          echo '<td>' . $plant['species'] . '</td>';
          echo '<td>' . $plant['family'] . '</td>';
          echo '<td><form action="edit_plant.php" method="post"><input type="hidden" name="plant_id" value="' . $plant['pid'] . '"><input type="submit" value="Edit"></form></td>';
          echo '</tr>';
        }
        echo '</table>';
      } else {
        echo '<p class="no-results">No results found.</p>';
      }
    }
    ?>

  </main>

</body>
</html>

