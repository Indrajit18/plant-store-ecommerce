<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protected Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F2F2F2;
            padding: 50px;
        }
        .container {
            background-color: #FFFFFF;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 0px 10px 2px #00000020;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to the Protected Page!</h1>
        <p>You have successfully logged in.</p>
        <p><a href="logout_user.php">Click here</a> to logout.</p>
    </div>
</body>
</html>
