<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$familyResult = $conn->query("SELECT * FROM family");
$soiltypeResult = $conn->query("SELECT * FROM soiltype");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Trees and Plants Ltd - Search</title>
    
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd</h1>
    </header>
    <nav>
        <ul>
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">More</a>
                <div class="dropdown-content">
                    <?php if(isset($_SESSION['loggedin'])): ?>
                        <a href="logout.php">Logout</a>
                        <a href="edit_profile.php">Edit Profile</a>
                        <a href="view_orders.php">Orders</a>
                        <p>Welcome, <?= $_SESSION['name'] ?></p>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="signup.php">Signup</a>
                    <?php endif; ?>
                    <a href="view_cart.php">Cart</a>
                    <a href="gardening_tips.php">Gardening Tips</a>
                </div>
            </li>
        </ul>
    </nav>
    <main>
        <section class="hero">
            <img src="trees_and_plants.jpg" alt="Trees and Plants" />
            <div class="quote">
                <h2><center> “The best time to plant a tree was 20 years ago. The second best time is now.”</center></h2>
            </div>
        </section>
        <h2>Search for Plants</h2>
        <form action="search_plant.php" method="get">
            <label for="family">Family:</label>
            <select name="family" id="family">
                <option value="">Select Family</option>
                <?php
                while ($row = $familyResult->fetch_assoc()) {
                    echo '<option value="'.$row['familyID'].'">'.$row['shortDesc'].'</option>';
                }
                ?>
            </select>
            <label for="soiltype">Soil Type:</label>
            <select name="soiltype" id="soiltype">
                <option value="">Select Soil Type</option>
                <?php
                while ($row = $soiltypeResult->fetch_assoc()) {
                    echo '<option value="'.$row['soilTypeID'].'">'.$row['shortDescription'].'</option>';
                }
                ?>
            </select>
            <div class="input-group">
                <label for="species">Species:</label>
                <input type="text" name="species" id="species">
            </div>
            <div class="input-group">
                <label for="shade">Shade:</label>
                <input type="number" name="shade" id="shade" min="1" max="5">
            </div>
            <div class="input-group">
                <label for="dampness">Dampness:</label>
                <input type="number" name="dampness" id="dampness" min="1" max="5">
            </div>
            <div class="input-group">
                <label for="colour">Colour:</label>
                <input type="text" name="colour" id="colour">
            </div>
            <div class="input-group">
                <label for="size">Height:</label>
                <input type="number" name="size" id="size">
            </div>
            <div class="input-group" >
                <input type="submit" value="Search">
            </div>
        </form>
    </main>
    <footer>
        <p>&copy; <?= date('Y') ?> Trees and Plants Ltd</p>
    </footer>
</body>
</html>
<?php
$conn->close(); 

