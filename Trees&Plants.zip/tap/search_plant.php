<?php 
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$family = isset($_POST['family']) ? $_POST['family'] : '';
$soiltype = isset($_POST['soiltype']) ? $_POST['soiltype'] : '';
$species = isset($_POST['species']) ? $_POST['species'] : '';
$shade = isset($_POST['shade']) ? $_POST['shade'] : '';
$dampness = isset($_POST['dampness']) ? $_POST['dampness'] : '';
$colour = isset($_POST['colour']) ? $_POST['colour'] : '';

$query = "SELECT * FROM plant WHERE 1";

if ($family) {
    $query .= " AND familyID = " . $family;
}

if ($soiltype) {
    $query .= " AND EXISTS (SELECT 1 FROM trees WHERE plant.pid = trees.tid AND trees.soilTypeID = " . $soiltype . ")";
}

if ($species) {
    $query .= " AND species = '" . mysqli_real_escape_string($conn, $species) . "'";
}

if ($shade) {
    $query .= " AND shade = " . $shade;
}

if ($dampness) {
    $query .= " AND dampness = " . $dampness;
}

if ($colour) {
    $query .= " AND colour LIKE '%" . $colour . "%'";
}

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Trees and Plants Ltd - Search</title>
    <nav>
    <ul>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">More</a>
            <div class="dropdown-content">
            <a href="index.php">Home</a>
                <a href="view_cart.php">Cart</a>
                
            </div>
        </li>
    </ul>
</nav>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd</h1>
    </header>
    <main>
        <h2>Search for Plants</h2>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Plant Name</th><th>Species</th><th>Description</th><th>Image</th><th>Add to Cart</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['Species']) . "</td>";
                echo "<td>" . htmlspecialchars($row['description']) . "</td>"; 
                
                echo "<td><img src='plant_images/" . htmlspecialchars($row['image']) . "' alt='' width='250'></td>"; 
                echo "<td>";
                echo "<form action='add_to_cart.php' method='post'>";
                echo "<input type='hidden' name='plant_id' value='" . htmlspecialchars($row['pid']) . "'>";
                echo "<input type='submit' value='Add to Cart'>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
            
            echo "</table>";
        } else {
            echo "No results found.";
        }
        ?>
    </main>
</body>
</html>
<?php
$conn->close();
?>

