<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Getting families and soil types from the database
$familyResult = $conn->query("SELECT * FROM family");
$soiltypeResult = $conn->query("SELECT * FROM soiltype");

// Checking if the form was submitted properly
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collecting form data
    $familyID = $_POST["family"];
    $species = $_POST["species"];
    $variety = $_POST["variety"];
    $quantity = $_POST["quantity"];
    $size = $_POST["size"];
    $shade = $_POST["shade"];
    $dampness = $_POST["dampness"];
    $colour = $_POST["colour"];
    $perenial = $_POST["perenial"];

    // Inserting new plant/tree into the appropriate table
    if ($familyID == 2) { // Tree
        $soilTypeID = $_POST["soiltype"];
        $growthRate = $_POST["growthRate"];

        $stmt = $conn->prepare("INSERT INTO trees (genus, familyID, species, variety, quantity, size, shade, soilTypeID, growthRate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisiiiiid", $species, $familyID, $species, $variety, $quantity, $size, $shade, $soilTypeID, $growthRate);
    } else { // Plant
        $stmt = $conn->prepare("INSERT INTO plant (familyID, Species, variety, quantity, size, shade, dampness, colour, perenial) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isiiiiisi", $familyID, $species, $variety, $quantity, $size, $shade, $dampness, $colour, $perenial);
    }

    // checking for errors
    if ($stmt->execute()) {
        echo "New plant/tree added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Closing the statement
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Trees and Plants Ltd - Data Entry</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
    background-color: #4CAF50;
    color: white;
    text-align: center;
    padding: 1rem;
    position: sticky;
    top: 0;
    z-index: 100;
}
        main {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px #ccc;
        }
        form {
            display: grid;
            grid-template-columns: 1fr 3fr;
            gap: 20px;
            align-items: center;
        }
        form label {
            justify-self: end;
            font-weight: bold;
        }
        form input[type="submit"] {
            grid-column: span 2;
            justify-self: center;
            padding: 10px 20px;
            background-color: white,green;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        form input[type="submit"]:hover {
            background-color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd - Data Entry</h1>
    </header>
    <main>
        <h2>Add a New Plant or Tree</h2>
        <form action="data_entry.php" method="post">
            <label for="family">Family:</label>
            <select name="family" id="family" required>
                <option value="">--Select Family--</option>
                <?php
                while ($row = $familyResult->fetch_assoc()) {
                    echo '<option value="' . $row["familyID"] . '">' . $row["shortDesc"] . '</option>';
                }
                ?>
            </select>
            <label for="species">Species:</label>
            <input type="text" name="species" id="species" required>
            <label for="variety">Variety:</label>
            <input type="text" name="variety" id="variety" required>
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" id="quantity" required>
            <label for="size">Size:</label>
            <input type="number" name="size" id="size" required>
            <label for="shade">Shade:</label>
            <input type="number" name="shade" id="shade" min="1" max="5" required>
            <label for="dampness">Dampness:</label>
            <input type="number" name="dampness" id="dampness" min="1" max="5" required>
            <label for="colour">Colour:</label>
            <input type="text" name="colour" id="colour" required>
            <label for="perenial">Perennial:</label>
            <input type="checkbox" name="perenial" id="perenial" value="1">
            <label for="soiltype">Soil Type:</label>
            <select name            ="soiltype" id="soiltype">
                <option value="">--Select Soil Type--</option>
                <?php
                while ($row = $soiltypeResult->fetch_assoc()) {
                    echo '<option value="' . $row["soilTypeID"] . '">' . $row["shortDescription"] . '</option>';
                }
                ?>
            </select>
            <label for="growthRate">Growth Rate:</label>
            <input type="number" name="growthRate" id="growthRate" step="0.1">
            <input type="submit" value="Add Plant/Tree">
        </form>
    </main>
</body>
</html>
<?php
// Closing the connection to the database
$conn->close();
?>

