<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trees and Plants Ltd - Gardening Tips</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f0f8ff;
    }

    header {
      background-color: #228b22;
      color: white;
      padding: 10px;
      text-align: center;
    }

    main {
      padding: 20px;
    }

    footer {
      background-color: #228b22;
      color: white;
      text-align: center;
      padding: 10px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .dropdown-content a {
      color: black;
      text-decoration: none;
    }

    h2, h3 {
      color: #228b22;
    }

    a {
      color: #006400;
    }
  </style>
</head>
<body>
  <header>

    <h1>Trees and Plants Ltd</h1>
    
  </header>
  <main>
    <h2>Gardening Tips</h2>
    <ul>
      <li>Always clean your tools after use.</li>
      <li>Water plants in the early morning or late evening when temperatures are cooler.</li>
      <li>Check plants regularly to detect any plant diseases or pests early.</li>
      <li>Remove any dead leaves or plants to prevent spread of disease.</li>
      <li>Feed your plants with plant food every month during growing season.</li>
      <li>When planting a new plant, make sure to loosen the roots before planting.</li>
      <li>Always use a good quality soil for your plants.</li>
      <li>Make sure to prune your plants to promote growth and a balanced structure.</li>
    </ul>
    <h3>Want to learn more?</h3>
    <p>For more in-depth information about gardening and plants, check out these articles on Wikipedia:</p>
    <ul>
      <li><a href="https://en.wikipedia.org/wiki/Gardening" target="_blank">Gardening</a></li>
      <li><a href="https://en.wikipedia.org/wiki/Plant" target="_blank">Plants</a></li>
      <li><a href="https://en.wikipedia.org/wiki/Plant_nutrition" target="_blank">Plant Nutrition</a></li>
      <!-- More links can be added here -->
    </ul>
  </main>
  <footer>
  <nav>
    <ul>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">More</a>
            <div class="dropdown-content">
            <a href="index.php">Home</a>
                <a href="view_cart.php">Cart</a>
                
                
                <!-- Add more links here -->
            </div>
        </li>
    </ul>
</nav>
  </footer>
</body>
</html>
