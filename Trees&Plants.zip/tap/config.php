<?php


// Establishing a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function get_plant_families($conn) {
  $sql = "SELECT * FROM family";
  $result = mysqli_query($conn, $sql);
  $families = array();
  
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
      $families[] = $row;
    }
  }
  
  return $families;
}
function search_plants($conn, $search) {
    $search = trim($search);
    $query = "SELECT p.pid, p.species, f.shortDesc as family FROM plant p INNER JOIN family f ON p.familyID = f.familyID WHERE p.species LIKE ? OR p.pid = ?";

    $stmt = $conn->prepare($query);
    $search_param = '%' . $search . '%';
    $stmt->bind_param('ss', $search_param, $search);
    $stmt->execute();

    $result = $stmt->get_result();
    $plants = [];
    while ($row = $result->fetch_assoc()) {
        $plants[] = $row;
    }

    return $plants;
}
function get_plant_by_id($conn, $plant_id) {
    $sql = "SELECT * FROM plant WHERE pid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $plant_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $plant = $result->fetch_assoc();

    return $plant;
}


function update_plant($conn, $plant_id, $species, $family) {
    $sql = "UPDATE plant SET species = ?, familyID = ? WHERE pid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $species, $family, $plant_id);
    return $stmt->execute();
}
?>
