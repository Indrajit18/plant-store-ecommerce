<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query based on the search criteria
$sql = "SELECT p.*, f.shortDesc as familyShortDesc, s.shortDescription as soilShortDesc FROM plant p
        JOIN family f ON p.familyID = f.familyID
        JOIN soiltype s ON p.soilTypeID = s.soilTypeID
        WHERE 1=1";

// Add conditions based on the search criteria
if (!empty($_GET["family"])) {
    $family = $conn->real_escape_string($_GET["family"]);
    $sql .= " AND p.familyID = '$family'";
}
if (!empty($_GET["soiltype"])) {
    $soiltype = $conn->real_escape_string($_GET["soiltype"]);
    $sql .= " AND p.soilTypeID = '$soiltype'";
}
if (!empty($_GET["shade"])) {
    $shade = $conn->real_escape_string($_GET["shade"]);
    $sql .= " AND p.shade = '$shade'";
}
if (!empty($_GET["dampness"])) {
    $dampness = $conn->real_escape_string($_GET["dampness"]);
    $sql .= " AND p.dampness = '$dampness'";
}
if (!empty($_GET["colour"])) {
    $colour = $conn->real_escape_string($_GET["colour"]);
    $sql .= " AND p.colour = '$colour'";
}

$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Search Results - Trees and Plants Ltd</title>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd</h1>
    </header>
    <main>
        <h2>Search Results</h2>
        <?php



        if ($result->num_rows > 0) {
            echo "<ul class='plant-list'>";
            while($row = $result->fetch_assoc()) {
                echo "<li>";
                // Display plant information
                echo "<h3>".$row["Species"]." - ".$row["variety"]."</h3>";
                echo "<p>Family: ".$row["familyShortDesc"]."</p>";
                echo "<p>Soil Type: ".$row["soilShortDesc"]."</p>";
                echo "<p>Shade: ".$row["shade"]."</p>";
                echo "<p>Dampness: ".$row["dampness"]."</p>";
                echo "<p>Colour: ".$row["colour"]."</p>";
                echo "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>No plants found matching your search criteria.</p>";
        }

        
        ?>
        <p><a href="index.php">Back to Search</a></p>
    </main>
</body>
</html>
<?php
$conn->close();
