<?php
session_start();

// Establishing a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function get_plant_by_id($conn, $plant_id) {
    $sql = "SELECT * FROM plant WHERE pid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $plant_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $plant = $result->fetch_assoc();

    return $plant;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Cart</title>
    <nav>
    <ul>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropbtn">More</a>
            <div class="dropdown-content">
            <a href="index.php">Home</a>
             <a href="view_cart.php">Cart</a>
                
            </div>
        </li>
    </ul>
</nav>

</head>
<body>
    <header>
        <h1>Trees and Plants Ltd - Cart</h1>
    </header>   
    <main>
        <h2>Your Cart</h2>
        <?php
        if (!empty($_SESSION['cart'])) {
            echo "<table>";
            echo "<tr><th>Image</th><th>Plant Name</th><th>Quantity</th><th>Action</th></tr>";
            foreach ($_SESSION['cart'] as $plant_id => $quantity) {
                $plant = get_plant_by_id($conn, $plant_id);
                echo "<tr>";
                echo "<td><img src='plant_images/" . htmlspecialchars($plant['image']) . "' alt='' width='100'></td>";  // display the plant image
                echo "<td>" . htmlspecialchars($plant['name']) . "</td>";
                echo "<td>";
                echo "<button class='quantity-btn' onclick=\"window.location.href='decrease_quantity.php?plant_id=" . urlencode($plant_id) . "'\">-</button>";
                echo htmlspecialchars($quantity);
                echo "<button class='quantity-btn' onclick=\"window.location.href='increase_quantity.php?plant_id=" . urlencode($plant_id) . "'\">+</button>";
                echo "</td>";
                echo "<td><a href='remove_from_cart.php?plant_id=" . urlencode($plant_id) . "'>Remove</a></td>";
                echo "</tr>";
            }
            echo "</table>";
            echo '<a href="add_address.php" class="checkout-button">Proceed to Checkout</a>';
        } else {
            echo "Your cart is empty.";
        }
        ?>
    </main>
</body>
</html>
<?php
$conn->close();
?>
