<?php

session_start();

$username = 'admin';
$password = 'password';

if (isset($_POST['txtUsername']) && isset($_POST['txtPassword'])) {
    if ($_POST['txtUsername'] === $username && $_POST['txtPassword'] === $password) {
        $_SESSION['loggedin'] = true;
        header("Location: admin.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .form-container {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f2f2f2;
        }
        .form-container input[type=text], .form-container input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 5px;
        }
        .form-container button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        .form-container button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <h2>Admin Login</h2>
    <div class="form-container">
        <form name="form" method="post" action="loginpage.php">
            <label for="txtUsername"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="txtUsername" required>

            <label for="txtPassword"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="txtPassword" required>

            <button type="submit" name="Submit">Login</button>
        </form>
    </div>
</body>
</html>
