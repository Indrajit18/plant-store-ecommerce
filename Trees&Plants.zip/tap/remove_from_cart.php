<?php
session_start();

$plant_id = $_GET['plant_id'];

if (!empty($_SESSION['cart'][$plant_id])) {
    unset($_SESSION['cart'][$plant_id]);
}

header('Location: view_cart.php');
?>
