<?php
session_start();
if(!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assessment";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userID = $_SESSION['id'];
$sql = "SELECT * FROM cart WHERE user_id = $userID";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Cart</title>
    </head>
<body>
    <h1>View Cart</h1>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Product ID: " . $row["product_id"]. " - Quantity: " . $row["quantity"]. "<br>";
        }
    } else {
        echo "Your cart is empty";
    }
    ?>
</body>
</html>

