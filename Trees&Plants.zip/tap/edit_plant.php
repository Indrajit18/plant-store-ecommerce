<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['update'])) {
        $plant_id = isset($_POST['plant_id']) ? $_POST['plant_id'] : '';
        $species = isset($_POST['species']) ? $_POST['species'] : '';
        $family = isset($_POST['family']) ? $_POST['family'] : '';

        $updated = update_plant($conn, $plant_id, $species, $family);
        if ($updated) {
            echo "Plant details updated successfully.";
        } else {
            echo "Failed to update plant details.";
        }
    } elseif(isset($_POST['plant_id'])) {
        $plant_id = isset($_POST['plant_id']) ? $_POST['plant_id'] : '';
        $plant = get_plant_by_id($conn, $plant_id);
        if ($plant) {
            // Display plant details and edit form
?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Edit Plant Details</title>
                <link rel="stylesheet" href="style.css">
                <style>
                    /* Add custom styles here */
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f2f2f2;
                        color: #333;
                    }
                    
                    header {
                        background-color: #4CAF50;
                        color: #fff;
                        padding: 20px;
                        text-align: center;
                    }
                    
                    h1 {
                        margin: 0;
                    }
                    
                    main {
                        padding: 20px;
                    }
                    
                    form {
                        margin-bottom: 20px;
                    }
                    
                    label {
                        font-weight: bold;
                    }
                    
                    input[type="text"] {
                        padding: 5px;
                        width: 200px;
                    }
                    
                    input[type="submit"] {
                        padding: 5px 10px;
                        background-color: #4CAF50;
                        color: #fff;
                        border: none;
                        cursor: pointer;
                    }
                    
                    input[type="submit"]:hover {
                        background-color: #45a049;
                    }
                    
                    .success-message {
                        color: #4CAF50;
                    }
                    
                    .error-message {
                        color: #f44336;
                    }
                </style>
            </head>
            <body>
                <header>
                    <h1>Edit Plant Details</h1>
                </header>
                
                <main>
                    <?php
                    if (isset($updated) && $updated) {
                        echo '<p class="success-message">Plant details updated successfully.</p>';
                    } elseif (isset($updated) && !$updated) {
                        echo '<p class="error-message">Failed to update plant details.</p>';
                    }
                    ?>
                    
                    <form action="edit_plant.php" method="post">
                        <input type="hidden" name="plant_id" value="<?php echo $plant['pid']; ?>">
                        <label for="species">Species:</label>
                        <input type="text" name="species" value="<?php echo isset($plant['species']) ? $plant['species'] : ''; ?>" required>
                        <label for="family">Family:</label>
<input type="text" id="family" name="family" value="<?php echo $plant['familyID']; ?>" required>
<input type="submit" name="update" value="Update">
</form>
</main>
</body>
</html>
<?php
} else {
echo '<p class="error-message">Plant not found.</p>';
}
} else {
header("Location: amend_details.php");
exit();
}
} else {
header("Location: amend_details.php");
exit();
}
?>

