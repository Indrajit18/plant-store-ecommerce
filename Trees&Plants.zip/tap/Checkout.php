<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Checkout</title>
</head>
<body>
    <header>
        <h1>Trees and Plants Ltd - Checkout</h1>
    </header>
    <main>
        <h2>Checkout Page</h2>
        <form class="checkout-form" action="process_payment.php" method="post">
            <label for="cardholder">Cardholder's Name:</label>
            <input type="text" id="cardholder" name="cardholder" required>

            <label for="cardnumber">Card Number:</label>
            <input type="text" id="cardnumber" name="cardnumber" required>

            <label for="expiry">Expiry Date:</label>
            <input type="month" id="expiry" name="expiry" required>

            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" name="cvv" required>

            <input type="submit" value="Pay Now">
        </form>
    </main>
</body>
</html>
