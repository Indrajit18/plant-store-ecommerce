// Start the session
session_start();

// Check if item ID and quantity are set
if (isset($_POST['id']) && isset($_POST['quantity'])) {
    // Update quantity in session cart
    $_SESSION['cart'][$_POST['id']] = $_POST['quantity'];
}

// Redirect back to the cart page
header('Location: view_cart.php');
exit;
